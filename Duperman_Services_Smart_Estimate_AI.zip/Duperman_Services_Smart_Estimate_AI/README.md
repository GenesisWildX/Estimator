# Duperman Services Smart Estimate (Python + AI)

A starter estimating app for landscaping and property maintenance. Includes:
- Dimensions and unit conversion
- Manual labor/materials/overhead/contingency/profit calculations
- Competitive, recommended, and premium bid modes
- Optional AI-generated draft task list, labor-hour ranges, questions, and risks
- Saved estimate history in SQLite
- Customer-facing estimate download and CSV export

## Run locally

1. Install Python 3.10 or newer.
2. Extract this folder.
3. Open a terminal in this folder and run:

   ```bash
   python -m venv .venv
   ```

   Activate the environment:
   - Windows: `.venv\Scripts\activate`
   - macOS/Linux: `source .venv/bin/activate`

4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the app:

   ```bash
   streamlit run app.py
   ```

6. Open the local URL shown in the terminal, usually `http://localhost:8501`.

## Turn on AI

- Create an OpenAI API key in your OpenAI account.
- Paste it into **OpenAI API key** in the app's sidebar.
- Keep the key private. Do not share the app publicly with the key hard-coded into the source.
- You can also set `OPENAI_API_KEY` as an environment variable before launching.
- The app uses the model name configured in the sidebar (default: `gpt-4.1-mini`). Availability and API pricing depend on your OpenAI account and current API offering.
- AI is optional; manual estimates work without a key.

## Before using for real bids

- Replace the example settings with the business's actual rates and costs.
- Confirm AI-generated labor estimates and every material quantity.
- Add site-specific assumptions, exclusions, taxes, and payment terms as needed.
- This is a starter app, not accounting, tax, legal, or construction-pricing advice.
- Data is stored in `estimates.db` on the machine/server running the app. Back it up; local data does not automatically sync between devices.
