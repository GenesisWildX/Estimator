import os
import json
import sqlite3
from datetime import date, datetime
from io import BytesIO

import pandas as pd
import streamlit as st

APP_TITLE = "Duperman Services | Smart Estimate"
DB_PATH = os.getenv("ESTIMATOR_DB_PATH", "estimates.db")

SERVICE_TYPES = [
    "Lawn mowing / edging",
    "Bush or hedge trimming",
    "Yard cleanup / debris removal",
    "Hand leveling / grading",
    "Mulch spreading",
    "Rock / gravel spreading",
    "Snow shoveling",
    "Salting / de-icing",
    "General maintenance",
    "Other",
]

UNIT_TO_METERS = {
    "inches": 0.0254,
    "feet": 0.3048,
    "centimeters": 0.01,
    "meters": 1.0,
    "yards": 0.9144,
}
AREA_TO_SQFT = {"sq ft": 1.0, "sq m": 10.7639104167, "sq yd": 9.0, "acres": 43560.0}

st.set_page_config(page_title=APP_TITLE, page_icon="🧰", layout="wide")

def db_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS estimates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            customer TEXT,
            job_address TEXT,
            service_type TEXT,
            description TEXT,
            estimated_hours REAL,
            labor_rate REAL,
            labor_total REAL,
            materials_total REAL,
            other_costs REAL,
            contingency_pct REAL,
            target_margin_pct REAL,
            bid_total REAL,
            notes TEXT
        )
    """)
    conn.commit()
    return conn

def save_estimate(data):
    conn = db_conn()
    conn.execute("""
        INSERT INTO estimates (
            created_at, customer, job_address, service_type, description,
            estimated_hours, labor_rate, labor_total, materials_total, other_costs,
            contingency_pct, target_margin_pct, bid_total, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        datetime.now().isoformat(timespec="seconds"), data["customer"], data["job_address"],
        data["service_type"], data["description"], data["hours"], data["labor_rate"],
        data["labor_total"], data["materials_total"], data["other_costs"],
        data["contingency_pct"], data["target_margin_pct"], data["bid_total"], data["notes"]
    ))
    conn.commit()
    conn.close()

def load_estimates():
    conn = db_conn()
    df = pd.read_sql_query("SELECT * FROM estimates ORDER BY id DESC", conn)
    conn.close()
    return df

def ai_breakdown(api_key, model, job_text, service_type, dimensions_text, crew_size):
    try:
        from openai import OpenAI
    except ImportError:
        return None, "The OpenAI package is not installed. Run: pip install -r requirements.txt"

    client = OpenAI(api_key=api_key)
    instructions = """
You are an estimating assistant for a small Utah landscaping and property-maintenance business.
Create a PRELIMINARY, editable estimate plan. Do not claim to know live local market prices.
Do not invent supplier prices. Use labor-hour ranges and clearly state assumptions.
Work scope may include lawn care, bush trimming, yard cleanup, hand leveling, mulch/rock spreading,
snow shoveling and salting, and general maintenance. Electrical and HVAC work are out of scope;
recommend a qualified subcontractor for those tasks. Do not imply licensing or safety compliance.
Return valid JSON only with this schema:
{
 "summary": "short scope summary",
 "tasks": [{"task":"...", "hours_low":0.5, "hours_high":1.0, "materials_or_equipment":"...", "quantity_or_assumption":"..."}],
 "questions": ["..."],
 "risks_and_exclusions": ["..."],
 "measurement_notes": ["..."]
}
Use realistic but cautious labor ranges; account for setup, travel at site if described, cleanup, access,
disposal, slope, weather, and equipment only when relevant. If information is missing, ask questions
rather than silently assuming. Do not provide a final customer price.
"""
    user = f"""Service category: {service_type}
Crew size: {crew_size}
Measurements supplied by user: {dimensions_text or 'None supplied'}
Job description:
{job_text}

Produce a preliminary task breakdown with low/high hours and questions. Assume the user will review it.
"""
    try:
        response = client.chat.completions.create(
            model=model,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": instructions},
                {"role": "user", "content": user},
            ],
            temperature=0.2,
        )
        parsed = json.loads(response.choices[0].message.content)
        return parsed, None
    except Exception as e:
        return None, f"AI request failed: {e}"

def money(x):
    return f"${x:,.2f}"

if "ai_result" not in st.session_state:
    st.session_state.ai_result = None
if "ai_error" not in st.session_state:
    st.session_state.ai_error = None

st.title("🧰 Duperman Services — Smart Estimate")
st.caption("A practical estimating starter app for landscaping and property maintenance. AI suggestions are drafts; review every quantity, hour, and price before sending a bid.")

with st.sidebar:
    st.header("Business pricing")
    st.caption("Edit these assumptions to match actual costs and local conditions.")
    labor_rate = st.number_input("Billable labor rate ($/worker-hour)", min_value=0.0, value=65.0, step=5.0)
    crew_size = st.number_input("Workers on this job", min_value=1, max_value=20, value=1, step=1)
    minimum_charge = st.number_input("Minimum service charge ($)", min_value=0.0, value=75.0, step=5.0)
    overhead_pct = st.number_input("Overhead allowance (%)", min_value=0.0, max_value=100.0, value=10.0, step=1.0)
    contingency_pct = st.number_input("Contingency (%)", min_value=0.0, max_value=100.0, value=10.0, step=1.0)
    target_margin_pct = st.number_input("Target gross profit margin (%)", min_value=0.0, max_value=80.0, value=35.0, step=1.0)
    st.divider()
    st.header("AI settings")
    api_key = st.text_input("OpenAI API key", type="password", value=os.getenv("OPENAI_API_KEY", ""), help="Optional. Key is used for this session and is not saved into the estimate database.")
    model = st.text_input("Model", value=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"))
    st.caption("AI requires internet access and an OpenAI API key. Without it, the manual estimator still works.")

tab_new, tab_history, tab_help = st.tabs(["➕ New estimate", "📚 Saved estimates", "ℹ️ How to use"])

with tab_new:
    left, right = st.columns([1.1, 0.9])
    with left:
        st.subheader("1. Customer and job")
        customer = st.text_input("Customer name")
        job_address = st.text_input("Job address / area")
        service_type = st.selectbox("Service category", SERVICE_TYPES)
        description = st.text_area(
            "Describe the work and problem",
            placeholder="Example: Front yard needs spring cleanup, remove leaves and branches, trim three shrubs, and spread 2 cubic yards of mulch.",
            height=130,
        )
        special_notes = st.text_area("Access, slope, disposal, weather, exclusions, or other notes", height=80)

        st.subheader("2. Measurements (optional)")
        st.caption("Enter dimensions in the units you have. The app converts length measurements to feet and calculates area when both length and width are provided.")
        c1, c2, c3 = st.columns(3)
        with c1:
            length = st.number_input("Length", min_value=0.0, value=0.0, step=1.0)
            length_unit = st.selectbox("Length unit", list(UNIT_TO_METERS.keys()), index=1)
        with c2:
            width = st.number_input("Width", min_value=0.0, value=0.0, step=1.0)
            width_unit = st.selectbox("Width unit", list(UNIT_TO_METERS.keys()), index=1)
        with c3:
            area_unit = st.selectbox("Show calculated area as", list(AREA_TO_SQFT.keys()), index=0)
            material_waste = st.number_input("Extra material allowance (%)", min_value=0.0, max_value=100.0, value=10.0, step=1.0)
        length_ft = length * UNIT_TO_METERS[length_unit] / UNIT_TO_METERS["feet"]
        width_ft = width * UNIT_TO_METERS[width_unit] / UNIT_TO_METERS["feet"]
        area_sqft = length_ft * width_ft if length > 0 and width > 0 else 0.0
        area_display = area_sqft / AREA_TO_SQFT[area_unit] if area_sqft else 0.0
        if area_sqft:
            st.info(f"Converted dimensions: **{length_ft:.2f} ft × {width_ft:.2f} ft** · Area: **{area_display:,.2f} {area_unit}** · With {material_waste:.0f}% allowance: **{area_sqft * (1 + material_waste/100):,.2f} sq ft equivalent**")
        dimensions_text = ""
        if length > 0:
            dimensions_text += f"Length {length} {length_unit} ({length_ft:.2f} ft). "
        if width > 0:
            dimensions_text += f"Width {width} {width_unit} ({width_ft:.2f} ft). "
        if area_sqft:
            dimensions_text += f"Calculated area {area_sqft:.2f} sq ft; allowance {material_waste:.0f}%. "
        dimensions_text += special_notes

    with right:
        st.subheader("3. AI job analysis")
        st.write("Ask AI to suggest a task list, estimated labor-hour range, missing questions, and risks. It will not set material prices for you.")
        if st.button("✨ Analyze job with AI", type="primary", use_container_width=True):
            if not api_key:
                st.session_state.ai_result = None
                st.session_state.ai_error = "Add an OpenAI API key in the sidebar to use AI."
            elif not description.strip():
                st.session_state.ai_result = None
                st.session_state.ai_error = "Describe the job first."
            else:
                with st.spinner("Analyzing job scope..."):
                    result, error = ai_breakdown(api_key, model, description, service_type, dimensions_text, int(crew_size))
                    st.session_state.ai_result = result
                    st.session_state.ai_error = error
        if st.session_state.ai_error:
            st.warning(st.session_state.ai_error)
        ai_result = st.session_state.ai_result
        ai_hours_low = 0.0
        ai_hours_high = 0.0
        if ai_result:
            st.markdown(f"**Scope summary:** {ai_result.get('summary', '')}")
            tasks = ai_result.get("tasks", [])
            if tasks:
                st.markdown("**Suggested tasks**")
                task_df = pd.DataFrame(tasks)
                st.dataframe(task_df, use_container_width=True, hide_index=True)
                ai_hours_low = sum(float(t.get("hours_low", 0) or 0) for t in tasks)
                ai_hours_high = sum(float(t.get("hours_high", 0) or 0) for t in tasks)
                st.metric("Suggested labor range (worker-hours)", f"{ai_hours_low:.1f}–{ai_hours_high:.1f}")
                st.caption(f"At {int(crew_size)} worker(s), rough elapsed time is {ai_hours_low/int(crew_size):.1f}–{ai_hours_high/int(crew_size):.1f} hours if work can be split efficiently.")
            for title, key in [("Questions to confirm", "questions"), ("Risks and exclusions", "risks_and_exclusions"), ("Measurement notes", "measurement_notes")]:
                values = ai_result.get(key, [])
                if values:
                    st.markdown(f"**{title}**")
                    for item in values:
                        st.write(f"• {item}")
            if st.button("Use midpoint of AI hours", use_container_width=True):
                st.session_state["hours_input"] = round((ai_hours_low + ai_hours_high) / 2, 2)
                st.rerun()

    st.divider()
    st.subheader("4. Build the price")
    p1, p2, p3 = st.columns(3)
    with p1:
        hours = st.number_input("Estimated total worker-hours", min_value=0.0, value=float(st.session_state.get("hours_input", 2.0)), step=0.25, key="hours_input")
        hourly_labor = st.number_input("Override labor rate ($/worker-hour)", min_value=0.0, value=float(labor_rate), step=5.0)
    with p2:
        materials_total = st.number_input("Materials / supplies total ($)", min_value=0.0, value=0.0, step=10.0)
        equipment_disposal = st.number_input("Equipment, disposal, delivery, travel ($)", min_value=0.0, value=0.0, step=5.0)
    with p3:
        other_costs = st.number_input("Other direct costs ($)", min_value=0.0, value=0.0, step=5.0)
        bid_style = st.selectbox("Bid strategy", ["Recommended profitable bid", "Competitive bid", "Premium / high-end defensible bid"])

    labor_total = hours * hourly_labor
    direct_costs = labor_total + materials_total + equipment_disposal + other_costs
    overhead_total = direct_costs * overhead_pct / 100
    cost_before_contingency = direct_costs + overhead_total
    contingency_total = cost_before_contingency * contingency_pct / 100
    estimated_cost = cost_before_contingency + contingency_total
    margin = target_margin_pct / 100
    if bid_style == "Competitive bid":
        selected_margin = max(0.10, margin - 0.10)
        selected_contingency = contingency_total * 0.5
    elif bid_style == "Premium / high-end defensible bid":
        selected_margin = min(0.80, margin + 0.10)
        selected_contingency = contingency_total
    else:
        selected_margin = margin
        selected_contingency = contingency_total
    cost_basis = direct_costs + overhead_total + selected_contingency
    if selected_margin >= 1:
        calculated_bid = cost_basis
    else:
        calculated_bid = cost_basis / max(0.01, (1 - selected_margin))
    calculated_bid = max(calculated_bid, minimum_charge)
    rounded_bid = round(calculated_bid / 5) * 5
    rounded_bid = max(minimum_charge, rounded_bid)
    projected_profit = rounded_bid - cost_basis
    projected_margin = (projected_profit / rounded_bid * 100) if rounded_bid else 0

    st.markdown("### Estimate preview")
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Labor", money(labor_total))
    k2.metric("Materials", money(materials_total))
    k3.metric("Estimated cost + overhead + contingency", money(estimated_cost))
    k4.metric("Suggested bid", money(rounded_bid))
    st.caption(f"Bid strategy: {bid_style}. This bid uses a target gross margin of {selected_margin*100:.0f}% and an estimated contingency of {money(selected_contingency)}. Estimated worker-hours: {hours:.2f}; approximate elapsed time with {int(crew_size)} worker(s): {hours/int(crew_size):.2f} hours.")
    if projected_profit < 0:
        st.error("This estimate is below the calculated cost basis. Review your inputs.")
    else:
        st.success(f"Projected gross profit before taxes and any omitted expenses: {money(projected_profit)} ({projected_margin:.1f}% of bid). Verify costs and scope before sending.")
    with st.expander("See internal cost breakdown"):
        st.write({
            "Labor": money(labor_total),
            "Materials and supplies": money(materials_total),
            "Equipment/disposal/delivery/travel": money(equipment_disposal),
            "Other direct costs": money(other_costs),
            "Overhead allowance": money(overhead_total),
            "Contingency in selected bid": money(selected_contingency),
            "Cost basis used for bid": money(cost_basis),
            "Target gross margin used": f"{selected_margin*100:.1f}%",
            "Rounded suggested bid": money(rounded_bid),
            "Projected gross profit": money(projected_profit),
        })

    customer_scope = st.text_area("Customer-facing scope of work", value=description, height=80)
    exclusions = st.text_area("Exclusions / assumptions to show customer", value="Price assumes the described scope and visible conditions. Hidden damage, additional work, extra disposal, or changes in scope require approval and may change the price.", height=70)
    estimate_notes = st.text_area("Internal notes (not included in customer PDF/text)", value=special_notes, height=60)

    quote_text = f"""DUPERMAN SERVICES
ESTIMATE
Date: {date.today().isoformat()}
Customer: {customer or '[Customer name]'}
Job address: {job_address or '[Job address]'}

SCOPE OF WORK
{customer_scope or '[Describe work included]'}

ESTIMATED SCHEDULE
Estimated labor: {hours:.2f} worker-hours
Approximate on-site duration: {hours/int(crew_size):.2f} hours with {int(crew_size)} worker(s), subject to site conditions.

ESTIMATED PRICE
Total proposed price: {money(rounded_bid)}

ASSUMPTIONS / EXCLUSIONS
{exclusions}

This estimate is based on the scope and assumptions above. Additional work or concealed conditions should be discussed and approved before proceeding.
"""
    st.download_button("⬇️ Download customer estimate (.txt)", data=quote_text, file_name=f"estimate_{date.today().isoformat()}.txt", mime="text/plain")
    if st.button("💾 Save estimate to job history", type="primary"):
        save_estimate({
            "customer": customer, "job_address": job_address, "service_type": service_type,
            "description": customer_scope, "hours": hours, "labor_rate": hourly_labor,
            "labor_total": labor_total, "materials_total": materials_total,
            "other_costs": equipment_disposal + other_costs, "contingency_pct": contingency_pct,
            "target_margin_pct": selected_margin * 100, "bid_total": rounded_bid,
            "notes": estimate_notes,
        })
        st.success("Estimate saved to local job history.")

with tab_history:
    st.subheader("Saved estimates on this device/server")
    history = load_estimates()
    if history.empty:
        st.info("No estimates saved yet. Build an estimate and choose “Save estimate to job history.”")
    else:
        show_cols = ["id", "created_at", "customer", "job_address", "service_type", "estimated_hours", "labor_total", "materials_total", "bid_total"]
        st.dataframe(history[show_cols], use_container_width=True, hide_index=True)
        csv = history.to_csv(index=False).encode("utf-8")
        st.download_button("Export all estimates to CSV", data=csv, file_name="duperman_estimates.csv", mime="text/csv")
        selected_id = st.number_input("Estimate ID to view", min_value=1, step=1, value=int(history.iloc[0]["id"]))
        selected = history[history["id"] == selected_id]
        if not selected.empty:
            st.json(selected.iloc[0].where(pd.notnull(selected.iloc[0]), None).to_dict())

with tab_help:
    st.subheader("Getting started")
    st.markdown("""
1. Set the business's actual hourly rate, overhead, contingency, target margin, and minimum charge in the sidebar.
2. Enter the customer and describe the job. Measurements are optional.
3. If you add an OpenAI API key, select **Analyze job with AI** for a draft task list, labor-hour range, questions, and risk notes.
4. Review and edit the AI suggestions. Enter actual expected materials and other direct costs.
5. Choose a bid strategy and review the cost breakdown before issuing the quote.
6. Download the customer-facing estimate and save a copy to job history.

### Important notes
- The example pricing settings are placeholders, not verified local market rates. Set them to match your business.
- AI outputs can be wrong or incomplete. Confirm measurements, quantities, hours, disposal fees, materials, and site conditions.
- This starter version stores estimates in a local SQLite database on the computer/server running the app. It is not automatically synced between devices.
- Do not enter sensitive customer information unless you are comfortable with your app's hosting and AI data practices.
- Electrical and HVAC work should be referred to qualified professionals, consistent with your stated work scope.
- For real use across multiple phones, add secure cloud hosting, authentication, backups, and a privacy review before storing customer data.
""")
