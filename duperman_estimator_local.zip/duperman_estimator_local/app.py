import os
import sqlite3
import uuid
from datetime import datetime
from pathlib import Path
from io import BytesIO

import streamlit as st
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, KeepTogether

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "jobs.db"
UPLOAD_DIR = APP_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

st.set_page_config(page_title="Duperman Services Job Estimator", page_icon="🧰", layout="wide")


def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            customer_name TEXT,
            phone TEXT,
            email TEXT,
            address TEXT,
            job_title TEXT,
            description TEXT,
            labor_hours REAL DEFAULT 0,
            labor_rate REAL DEFAULT 0,
            materials_cost REAL DEFAULT 0,
            materials_markup_pct REAL DEFAULT 0,
            gas_cost REAL DEFAULT 0,
            miles REAL DEFAULT 0,
            mileage_rate REAL DEFAULT 0,
            other_cost REAL DEFAULT 0,
            overhead_pct REAL DEFAULT 0,
            profit_pct REAL DEFAULT 0,
            tax_pct REAL DEFAULT 0,
            notes TEXT,
            status TEXT DEFAULT 'Estimate'
        )
    """)
    conn.commit()
    return conn


def money(value):
    return f"${float(value or 0):,.2f}"


def calculate(values):
    labor = max(0, float(values.get("labor_hours", 0) or 0)) * max(0, float(values.get("labor_rate", 0) or 0))
    materials_base = max(0, float(values.get("materials_cost", 0) or 0))
    materials = materials_base * (1 + max(0, float(values.get("materials_markup_pct", 0) or 0)) / 100)
    gas = max(0, float(values.get("gas_cost", 0) or 0))
    mileage = max(0, float(values.get("miles", 0) or 0)) * max(0, float(values.get("mileage_rate", 0) or 0))
    other = max(0, float(values.get("other_cost", 0) or 0))
    direct = labor + materials + gas + mileage + other
    overhead = direct * max(0, float(values.get("overhead_pct", 0) or 0)) / 100
    subtotal = direct + overhead
    profit = subtotal * max(0, float(values.get("profit_pct", 0) or 0)) / 100
    taxable = subtotal + profit
    tax = taxable * max(0, float(values.get("tax_pct", 0) or 0)) / 100
    total = taxable + tax
    return {
        "labor": labor, "materials": materials, "materials_base": materials_base,
        "materials_markup": materials - materials_base, "gas": gas, "mileage": mileage,
        "other": other, "direct": direct, "overhead": overhead, "subtotal": subtotal,
        "profit": profit, "tax": tax, "total": total
    }


def job_folder(job_id):
    folder = UPLOAD_DIR / job_id
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def save_uploads(job_id, files, category):
    folder = job_folder(job_id) / category
    folder.mkdir(parents=True, exist_ok=True)
    saved = []
    for uploaded in files or []:
        safe_name = Path(uploaded.name).name.replace(" ", "_")
        target = folder / f"{uuid.uuid4().hex[:8]}_{safe_name}"
        target.write_bytes(uploaded.getvalue())
        saved.append(target)
    return saved


def list_files(job_id, category):
    folder = UPLOAD_DIR / job_id / category
    if not folder.exists():
        return []
    return sorted([p for p in folder.iterdir() if p.is_file()])


def build_pdf(job, totals, photos, receipts):
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=letter, rightMargin=0.55*inch, leftMargin=0.55*inch,
        topMargin=0.55*inch, bottomMargin=0.55*inch
    )
    styles = getSampleStyleSheet()
    story = [
        Paragraph("Duperman Services", styles["Title"]),
        Paragraph("Job Estimate / Work Record", styles["Heading2"]),
        Spacer(1, 8),
        Paragraph(f"<b>Estimate ID:</b> {job['id']}", styles["Normal"]),
        Paragraph(f"<b>Created:</b> {job['created_at']}", styles["Normal"]),
        Paragraph(f"<b>Status:</b> {job['status']}", styles["Normal"]),
        Spacer(1, 10),
        Paragraph("Customer & Job Details", styles["Heading2"]),
    ]
    details = [
        ["Customer", job["customer_name"] or ""],
        ["Phone", job["phone"] or ""],
        ["Email", job["email"] or ""],
        ["Address", job["address"] or ""],
        ["Job", job["job_title"] or ""],
        ["Description", (job["description"] or "").replace("\n", "<br/>")],
    ]
    table = Table(details, colWidths=[1.2*inch, 5.8*inch])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (0,-1), colors.whitesmoke),
        ("GRID", (0,0), (-1,-1), 0.4, colors.lightgrey),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("LEFTPADDING", (0,0), (-1,-1), 6),
        ("RIGHTPADDING", (0,0), (-1,-1), 6),
        ("TOPPADDING", (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
    ]))
    story += [table, Spacer(1, 12), Paragraph("Estimate Breakdown", styles["Heading2"])]
    rows = [
        ["Item", "Calculation", "Amount"],
        ["Labor", f"{job['labor_hours']:g} hours × {money(job['labor_rate'])}/hr", money(totals["labor"])],
        ["Materials", f"Base {money(totals['materials_base'])} + {job['materials_markup_pct']:g}% markup", money(totals["materials"])],
        ["Gas / fuel", "Entered cost", money(totals["gas"])],
        ["Mileage", f"{job['miles']:g} miles × {money(job['mileage_rate'])}/mile", money(totals["mileage"])],
        ["Other expenses", "Entered cost", money(totals["other"])],
        ["Direct costs", "", money(totals["direct"])],
        [f"Overhead ({job['overhead_pct']:g}%)", "", money(totals["overhead"])],
        ["Subtotal", "", money(totals["subtotal"])],
        [f"Profit ({job['profit_pct']:g}%)", "", money(totals["profit"])],
        [f"Tax ({job['tax_pct']:g}%)", "", money(totals["tax"])],
        ["ESTIMATED TOTAL", "", money(totals["total"])],
    ]
    t = Table(rows, colWidths=[1.8*inch, 3.5*inch, 1.7*inch], repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#243447")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("GRID", (0,0), (-1,-1), 0.4, colors.lightgrey),
        ("ALIGN", (2,1), (2,-1), "RIGHT"),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("BACKGROUND", (0,-1), (-1,-1), colors.HexColor("#e8f1f8")),
        ("FONTNAME", (0,-1), (-1,-1), "Helvetica-Bold"),
        ("TOPPADDING", (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
    ]))
    story += [t, Spacer(1, 10)]
    if job["notes"]:
        story += [Paragraph("Notes / Terms", styles["Heading2"]),
                  Paragraph(job["notes"].replace("\n", "<br/>"), styles["BodyText"]), Spacer(1, 8)]
    if photos:
        story.append(Paragraph("Photos", styles["Heading2"]))
        for path in photos:
            try:
                story.append(KeepTogether([Paragraph(path.name, styles["Caption"]),
                                           Image(str(path), width=3.0*inch, height=2.2*inch, kind="proportional")]))
                story.append(Spacer(1, 6))
            except Exception:
                story.append(Paragraph(f"Photo file saved separately: {path.name}", styles["Normal"]))
    if receipts:
        story += [Paragraph("Receipt / Attachment Files", styles["Heading2"])]
        story.append(Paragraph("The following files are saved with this job and should be sent separately with this PDF if needed:", styles["BodyText"]))
        for path in receipts:
            story.append(Paragraph(f"• {path.name}", styles["Normal"]))
    story += [Spacer(1, 12), Paragraph(
        "This is an estimate, not a final invoice. Confirm scope, tax treatment, and pricing before sending to a customer.",
        styles["Italic"]
    )]
    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()


conn = connect_db()
st.title("🧰 Duperman Services — Job Estimator")
st.caption("Local-first starter version • Python + SQLite • No paid AI or API key required")

with st.sidebar:
    st.header("Navigation")
    page = st.radio("Choose a page", ["New / Edit Estimate", "Saved Jobs", "Local Setup Help"])
    st.divider()
    st.warning("Local data is stored in this project folder. Back up the whole folder, including jobs.db and uploads/.")

if page == "New / Edit Estimate":
    existing = conn.execute("SELECT id, job_title, customer_name FROM jobs ORDER BY updated_at DESC").fetchall()
    options = {"Create a new job": None}
    for row in existing:
        options[f"{row['job_title'] or 'Untitled job'} — {row['customer_name'] or 'No customer'} ({row['id'][:8]})"] = row["id"]
    selected_label = st.selectbox("Start new or edit a saved job", list(options.keys()))
    selected_id = options[selected_label]
    record = dict(conn.execute("SELECT * FROM jobs WHERE id=?", (selected_id,)).fetchone()) if selected_id else {}
    if selected_id:
        st.info(f"Editing saved job {selected_id}")

    with st.form("job_form"):
        st.subheader("Customer and job")
        c1, c2 = st.columns(2)
        with c1:
            customer_name = st.text_input("Customer name", value=record.get("customer_name", ""))
            phone = st.text_input("Phone", value=record.get("phone", ""))
            email = st.text_input("Email", value=record.get("email", ""))
            address = st.text_area("Job address", value=record.get("address", ""), height=80)
        with c2:
            job_title = st.text_input("Job title", value=record.get("job_title", ""))
            status = st.selectbox("Status", ["Estimate", "Approved", "In progress", "Completed", "Cancelled"],
                                  index=["Estimate", "Approved", "In progress", "Completed", "Cancelled"].index(record.get("status", "Estimate")))
            description = st.text_area("Description of what is happening / work needed",
                                       value=record.get("description", ""), height=140)
        st.subheader("Costs and rates")
        c1, c2, c3 = st.columns(3)
        with c1:
            labor_hours = st.number_input("Labor hours", min_value=0.0, value=float(record.get("labor_hours", 0)), step=0.25)
            labor_rate = st.number_input("Labor rate ($/hour)", min_value=0.0, value=float(record.get("labor_rate", 0)), step=5.0)
            materials_cost = st.number_input("Materials cost before markup ($)", min_value=0.0, value=float(record.get("materials_cost", 0)), step=10.0)
            materials_markup_pct = st.number_input("Materials markup (%)", min_value=0.0, value=float(record.get("materials_markup_pct", 0)), step=1.0)
        with c2:
            gas_cost = st.number_input("Gas / fuel cost ($)", min_value=0.0, value=float(record.get("gas_cost", 0)), step=5.0)
            miles = st.number_input("Miles traveled", min_value=0.0, value=float(record.get("miles", 0)), step=1.0)
            mileage_rate = st.number_input("Mileage rate ($/mile)", min_value=0.0, value=float(record.get("mileage_rate", 0)), step=0.05)
            other_cost = st.number_input("Other expenses ($)", min_value=0.0, value=float(record.get("other_cost", 0)), step=5.0)
        with c3:
            overhead_pct = st.number_input("Overhead (%)", min_value=0.0, value=float(record.get("overhead_pct", 0)), step=1.0)
            profit_pct = st.number_input("Profit (%)", min_value=0.0, value=float(record.get("profit_pct", 0)), step=1.0)
            tax_pct = st.number_input("Tax (%)", min_value=0.0, value=float(record.get("tax_pct", 0)), step=0.1)
        notes = st.text_area("Notes, exclusions, payment terms, or completion details", value=record.get("notes", ""), height=100)
        submitted = st.form_submit_button("Save job and estimate", type="primary")

    values = {
        "labor_hours": labor_hours, "labor_rate": labor_rate, "materials_cost": materials_cost,
        "materials_markup_pct": materials_markup_pct, "gas_cost": gas_cost, "miles": miles,
        "mileage_rate": mileage_rate, "other_cost": other_cost, "overhead_pct": overhead_pct,
        "profit_pct": profit_pct, "tax_pct": tax_pct
    }
    totals = calculate(values)
    st.subheader("Live estimate preview")
    cols = st.columns(4)
    cols[0].metric("Labor", money(totals["labor"]))
    cols[1].metric("Materials incl. markup", money(totals["materials"]))
    cols[2].metric("Gas + mileage", money(totals["gas"] + totals["mileage"]))
    cols[3].metric("Estimated total", money(totals["total"]))
    st.caption("Calculation method: direct costs → overhead → profit → tax. Confirm your local tax rules and business pricing policy.")

    if submitted:
        now = datetime.now().isoformat(timespec="seconds")
        job_id = selected_id or uuid.uuid4().hex
        created_at = record.get("created_at", now)
        data = (
            job_id, created_at, now, customer_name, phone, email, address, job_title, description,
            labor_hours, labor_rate, materials_cost, materials_markup_pct, gas_cost, miles,
            mileage_rate, other_cost, overhead_pct, profit_pct, tax_pct, notes, status
        )
        conn.execute("""
            INSERT INTO jobs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
            updated_at=excluded.updated_at, customer_name=excluded.customer_name, phone=excluded.phone,
            email=excluded.email, address=excluded.address, job_title=excluded.job_title,
            description=excluded.description, labor_hours=excluded.labor_hours, labor_rate=excluded.labor_rate,
            materials_cost=excluded.materials_cost, materials_markup_pct=excluded.materials_markup_pct,
            gas_cost=excluded.gas_cost, miles=excluded.miles, mileage_rate=excluded.mileage_rate,
            other_cost=excluded.other_cost, overhead_pct=excluded.overhead_pct, profit_pct=excluded.profit_pct,
            tax_pct=excluded.tax_pct, notes=excluded.notes, status=excluded.status
        """, data)
        conn.commit()
        st.success(f"Saved! Job ID: {job_id}")
        st.rerun()

    if selected_id:
        st.divider()
        st.subheader("Photos and receipts")
        st.write("Upload before-work photos, after-work photos, receipts, or supporting documents. Files are stored in separate folders for this job.")
        before_files = st.file_uploader("Before-work photos (JPG/PNG)", type=["jpg", "jpeg", "png"], accept_multiple_files=True, key=f"before_{selected_id}")
        after_files = st.file_uploader("Completed-work photos (JPG/PNG)", type=["jpg", "jpeg", "png"], accept_multiple_files=True, key=f"after_{selected_id}")
        receipt_files = st.file_uploader("Receipts / other attachments (PDF, JPG, PNG)", type=["pdf", "jpg", "jpeg", "png"], accept_multiple_files=True, key=f"receipts_{selected_id}")
        if st.button("Save uploaded files"):
            saved_before = save_uploads(selected_id, before_files, "before")
            saved_after = save_uploads(selected_id, after_files, "after")
            saved_receipts = save_uploads(selected_id, receipt_files, "receipts")
            st.success(f"Saved {len(saved_before)} before photos, {len(saved_after)} completed photos, and {len(saved_receipts)} attachments.")
            st.rerun()
        before = list_files(selected_id, "before")
        after = list_files(selected_id, "after")
        receipts = list_files(selected_id, "receipts")
        st.write(f"Saved files: {len(before)} before photos · {len(after)} completed photos · {len(receipts)} receipts/attachments")
        if before or after or receipts:
            for file in before + after + receipts:
                st.write(f"📎 {file.relative_to(APP_DIR)}")
        row = conn.execute("SELECT * FROM jobs WHERE id=?", (selected_id,)).fetchone()
        if row:
            job = dict(row)
            job_values = {k: job[k] for k in values}
            saved_totals = calculate(job_values)
            pdf = build_pdf(job, saved_totals, before + after, receipts)
            st.download_button("Generate / download estimate PDF", data=pdf,
                               file_name=f"estimate_{selected_id[:8]}.pdf", mime="application/pdf")
            st.caption("Receipt files are listed in the PDF but remain separate attachments; attach them separately when emailing.")

elif page == "Saved Jobs":
    st.subheader("Saved jobs")
    rows = conn.execute("SELECT * FROM jobs ORDER BY updated_at DESC").fetchall()
    if not rows:
        st.info("No saved jobs yet. Create one under New / Edit Estimate.")
    else:
        for row in rows:
            job = dict(row)
            vals = {k: job[k] for k in ["labor_hours","labor_rate","materials_cost","materials_markup_pct","gas_cost","miles","mileage_rate","other_cost","overhead_pct","profit_pct","tax_pct"]}
            total = calculate(vals)["total"]
            with st.expander(f"{job['job_title'] or 'Untitled job'} — {job['customer_name'] or 'No customer'} | {job['status']} | {money(total)}"):
                st.write(f"**Job ID:** {job['id']}")
                st.write(f"**Last updated:** {job['updated_at']}")
                st.write(job["description"] or "No description entered.")
                st.write(f"**Address:** {job['address'] or 'Not entered'}")
                st.write(f"**Attachments:** {sum(len(list_files(job['id'], c)) for c in ['before','after','receipts'])}")
                st.caption("To edit or download its PDF, open New / Edit Estimate and select this job.")

else:
    st.subheader("Run this website on your computer")
    st.markdown("""
1. Install **Python 3.10 or newer** from the official Python website.
2. Extract this ZIP file into a folder you can find again.
3. Open Terminal (Mac) or Command Prompt / PowerShell (Windows) in that folder.
4. Create a virtual environment:
   - **Windows:** `py -m venv .venv` then `.venv\\Scripts\\activate`
   - **Mac:** `python3 -m venv .venv` then `source .venv/bin/activate`
5. Install dependencies: `python -m pip install -r requirements.txt`
6. Start the website: `python -m streamlit run app.py`
7. Your browser should open the local website. If it does not, open the local address printed in the terminal.
8. To keep your records safe, back up `jobs.db` and the entire `uploads` folder.
""")
    st.warning("This is a local starter application, not yet a secure multi-user hosted system. Keep the project folder private and back it up. Do not store real customer data on a shared computer.")
    st.write("This app does not call an AI service and does not require paid AI.")

conn.close()
