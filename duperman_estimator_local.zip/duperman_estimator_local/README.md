# Duperman Services — Local Python Job Estimator

This is a fresh, local-first starter app. It uses Python, Streamlit, SQLite, and ReportLab.
It does not require paid AI, an OpenAI API key, pandas, or a cloud database.

## Run locally

1. Install Python 3.10 or newer.
2. Extract the ZIP file.
3. Open a terminal in this folder.
4. Create and activate a virtual environment:

   Windows:
   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```

   macOS:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

5. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```

6. Run:
   ```bash
   python -m streamlit run app.py
   ```

The terminal will print a local URL, usually http://localhost:8501.

## Data and backups

- Job records are stored in `jobs.db`.
- Uploaded photos and receipts are stored under `uploads/<job-id>/`.
- Back up both `jobs.db` and the whole `uploads` folder regularly.
- This local app is intended for one computer/user during testing. It is not yet a secure hosted multi-user service.

## Pricing calculation

Direct costs = labor + materials (including material markup) + gas + mileage + other expenses.
Overhead is calculated as a percentage of direct costs.
Profit is calculated as a percentage of direct costs plus overhead.
Tax is calculated on the subtotal plus profit.

Check local tax requirements and your own business pricing rules before sending estimates.
